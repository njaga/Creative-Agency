export const useLoading = () => useState('loading', () => true)
