<template>
  <div>
    <!-- Contenu de la page applications -->
  </div>
</template> 