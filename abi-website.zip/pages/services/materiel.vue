<template>
  <div>
    <!-- Contenu de la page matériel -->
  </div>
</template> 